﻿using UnityEngine;
using System.Collections;

public class PlayerCollision : MonoBehaviour {

    void OnTriggerEnter()
    {
        Debug.Log("player 1 trigger");
    }
}
