﻿using UnityEngine;
using System.Collections;

public class player2Test : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    void FixedUpdate()
    {
       // Debug.Log("player2Alive");
        this.transform.position = this.transform.position + new Vector3(0, 0, 1f);
    }
    void OnTriggerEnter()
    {
        Debug.Log("player 2 trigger");
    }
}
