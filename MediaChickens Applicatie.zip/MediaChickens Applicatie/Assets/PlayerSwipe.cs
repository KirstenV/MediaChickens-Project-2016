﻿using UnityEngine;
using System.Collections;

public class PlayerSwipe : MonoBehaviour
{

    //variables for swipe
    private Touch initialTouchSwipe = new Touch();
    private float distanceSwipe = 0;
    private bool hasSwiped = false;
    private bool alive = true;
    void FixedUpdate() //always being called
    {
        //Debug.Log("alive");
        if (alive)
        {
            this.transform.position = this.transform.position + new Vector3(0, 0, 0.5f);
            foreach (Touch t in Input.touches)
            {
                if (t.phase == TouchPhase.Began)
                {
                    initialTouchSwipe = t;
                }
                else if (t.phase == TouchPhase.Moved && !hasSwiped)
                {
                    //distance formula
                    float deltaXSwipe = initialTouchSwipe.position.x - t.position.x;
                    float deltaYSwipe = initialTouchSwipe.position.y - t.position.y;
                    distanceSwipe = Mathf.Sqrt((deltaXSwipe * deltaXSwipe) + (deltaYSwipe * deltaYSwipe));
                    //direction
                    bool swipedSideways = Mathf.Abs(deltaXSwipe) > Mathf.Abs(deltaYSwipe); //swipe up and down or sideways
                    if (distanceSwipe > 100f)
                    {
                        if (swipedSideways && deltaXSwipe > 0) //swiped left
                        {
                            //this.transform.Rotate(new Vector3(0, -15f, 0));
                            this.transform.position = this.transform.position + new Vector3(-15f, 0, 0);
                        }
                        else if (swipedSideways && deltaXSwipe <= 0) //swiped right
                        {
                            //   this.transform.Rotate(new Vector3(0, 15f, 0));
                            this.transform.position = this.transform.position + new Vector3(15f, 0, 0);
                        }
                        else if (!swipedSideways && deltaYSwipe > 0) //swiped down
                        {
                            this.transform.Rotate(new Vector3(0, 180f, 0));

                        }
                        else if (!swipedSideways && deltaYSwipe <= 0) //swiped up
                        {

                        }
                        hasSwiped = true;
                    }

                }
                else if (t.phase == TouchPhase.Ended)
                {
                    initialTouchSwipe = new Touch(); //reset touch
                    hasSwiped = false;
                }


            }
        }


    }
}
