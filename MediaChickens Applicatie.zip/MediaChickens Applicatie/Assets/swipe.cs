﻿using UnityEngine;
using UnityEngine.UI;
//JSON
using System.Collections;


public class swipe : MonoBehaviour {
    //variables for swipe
    private Touch initialTouchSwipe = new Touch();
    private float distanceSwipe = 0;
    private bool hasSwiped = false;
    private bool alive = true;
    public Rigidbody rb;
    private float score;
    public Text scoreText;
    private float speed = 0.5f;
    private float levelUpTimer = 0;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        score = 0;
        
    }
    void OnTriggerEnter(Collider other)
    {
        Debug.Log("player test trigger");
        if (other.gameObject.CompareTag("Environment"))
        {
            //alive = false;

        }
    }
    void FixedUpdate() //always being called
    {
        score = Mathf.Round( Time.fixedTime * 100);
        scoreText.text = score.ToString();
        if((score - levelUpTimer) >= 1000)
        {
            levelUpTimer = score;
            Debug.Log("Going faster!" + levelUpTimer);
            speed += 0.5f;
        }
       
        if (alive)
        {
            this.transform.position = this.transform.position + new Vector3(0, 0, speed);
            foreach (Touch t in Input.touches)
            {
                if (t.phase == TouchPhase.Began)
                {
                    initialTouchSwipe = t;
                }
                else if (t.phase == TouchPhase.Moved && !hasSwiped)
                {
                    //distance formula
                    float deltaXSwipe = initialTouchSwipe.position.x - t.position.x;
                    float deltaYSwipe = initialTouchSwipe.position.y - t.position.y;
                    distanceSwipe = Mathf.Sqrt((deltaXSwipe * deltaXSwipe) + (deltaYSwipe * deltaYSwipe));
                    //direction
                    bool swipedSideways = Mathf.Abs(deltaXSwipe) > Mathf.Abs(deltaYSwipe); //swipe up and down or sideways
                    if (distanceSwipe > 100f)
                    {
                        if (swipedSideways && deltaXSwipe > 0) //swiped left
                        {
                            //this.transform.position = this.transform.position + new Vector3(-15f, 0, 0);
                            Physics.gravity = new Vector3(0, -30F, 0);
                            rb.AddForce(-50000f, 10000f, 0, ForceMode.Force);
                            
                            
                        }
                        else if (swipedSideways && deltaXSwipe <= 0) //swiped right
                        {
                            //   this.transform.Rotate(new Vector3(0, 15f, 0));
                            // this.transform.position = this.transform.position + new Vector3(15f, 0, 0);
                            Physics.gravity = new Vector3(0, -30F, 0);
                            rb.AddForce(50000f, 10000f, 0, ForceMode.Force);
                        }
                        else if (!swipedSideways && deltaYSwipe > 0) //swiped down
                        {
                           

                        }
                        else if (!swipedSideways && deltaYSwipe <= 0) //swiped up
                        {
                            Physics.gravity = new Vector3(0, -50F, 0);
                            rb.AddForce(0, 20000f, 0, ForceMode.Force);
                            
                        }
                        hasSwiped = true;
                    }

                }
                else if (t.phase == TouchPhase.Ended)
                {
                    initialTouchSwipe = new Touch(); //reset touch
                    hasSwiped = false;
                }


            }
        }
    }

    
        
   }
   